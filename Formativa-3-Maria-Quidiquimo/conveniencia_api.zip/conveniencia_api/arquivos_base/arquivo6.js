const express = require('express');
const router = express.Router();
const ProdutoController = require('../controllers/ProdutoController');

router.get('/', ProdutoController.listar);
router.get('/:id', ProdutoController.buscarPorId);
// TODO: A rota de POST foi removida. Procure no arquivo de trechos faltantes e cole aqui.
router.put('/:id', ProdutoController.atualizar);
router.delete('/:id', ProdutoController.deletar);

module.exports = router;
