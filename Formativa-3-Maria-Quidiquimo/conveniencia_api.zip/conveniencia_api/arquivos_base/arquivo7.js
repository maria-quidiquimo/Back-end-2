const ProdutoRepository = require('../repositories/ProdutoRepository');

class ProdutoService {
    async listarProdutos() {
        const produtos = await ProdutoRepository.findAll();
        return { sucesso: true, dados: produtos, total: produtos.length };
    }

    async buscarProdutoPorId(id) {
        if (!id || isNaN(id)) throw { status: 400, mensagem: "ID inválido" };
        const produto = await ProdutoRepository.findById(id);
        if (!produto) throw { status: 404, mensagem: "Produto não encontrado" };
        return { sucesso: true, dados: produto };
    }

    async cadastrarProduto(dados) {
        const { nome, descricao, preco, estoque, categoria, disponivel } = dados;
        if (!nome || !descricao || preco === undefined || estoque === undefined) {
            throw { status: 400, mensagem: "Nome, descrição, preço e estoque são obrigatórios" };
        }
        if (typeof preco !== "number" || preco < 0) {
            throw { status: 400, mensagem: "Preço deve ser um número positivo" };
        }
        if (typeof estoque !== "number" || estoque < 0) {
            throw { status: 400, mensagem: "Estoque não pode ser negativo" };
        }

        const novoProduto = {
            nome: nome.trim(),
            descricao: descricao.trim(),
            preco,
            estoque,
            categoria: categoria || null,
            disponivel: disponivel ?? true
        };

        const id = await ProdutoRepository.create(novoProduto);
        return { sucesso: true, mensagem: "Produto cadastrado com sucesso", id };
    }

    // TODO: O método atualizarProduto() foi removido. Procure no arquivo de trechos faltantes e cole aqui.

    async deletarProduto(id) {
        if (!id || isNaN(id)) throw { status: 400, mensagem: "ID inválido" };
        const existe = await ProdutoRepository.findById(id);
        if (!existe) throw { status: 404, mensagem: "Produto não encontrado" };

        await ProdutoRepository.delete(id);
        return { sucesso: true, mensagem: "Produto apagado com sucesso" };
    }
}

module.exports = new ProdutoService();
